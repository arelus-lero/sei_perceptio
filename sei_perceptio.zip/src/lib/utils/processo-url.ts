export function processoHref(nup: string): string {
  return `/processos/${encodeURIComponent(nup)}`;
}

export function nupFromRouteParam(routeNup: string): string {
  return decodeURIComponent(routeNup);
}

export function processoTimelineHref(nup: string): string {
  return `${processoHref(nup)}/timeline`;
}

export function processoApiPath(nup: string, suffix = ''): string {
  const base = `/api/processos/${encodeURIComponent(nup)}`;
  return suffix ? `${base}/${suffix}` : base;
}
