import { redirect } from 'next/navigation';
import type { ReactNode } from 'react';

import { GlossaryProviders } from '@/components/glossary/glossary-providers';
import { DashboardNav } from '@/components/layout/dashboard-nav';
import { InactivityTimeoutGuard } from '@/components/layout/inactivity-timeout-guard';
import { OnboardingProvider } from '@/components/onboarding/onboarding-provider';
import { getServerAuthContext } from '@/lib/auth/server-context';

interface DashboardLayoutProps {
  children: ReactNode;
}

export default async function DashboardLayout({ children }: DashboardLayoutProps) {
  const auth = await getServerAuthContext();

  if (!auth) {
    redirect('/login');
  }

  const { data: perfil } = await auth.supabase
    .from('perfil')
    .select('onboarding_concluido')
    .eq('user_id', auth.user.id)
    .eq('orgao_id', auth.orgaoId)
    .maybeSingle();

  const onboardingConcluido = perfil?.onboarding_concluido === true;

  return (
    <InactivityTimeoutGuard>
      <GlossaryProviders>
        <OnboardingProvider onboardingConcluido={onboardingConcluido}>
          <div className="flex min-h-full flex-1">
            <DashboardNav isAdmin={auth.role === 'admin'} />
            <main
              id="main-content"
              tabIndex={-1}
              className="flex min-h-full min-w-0 flex-1 flex-col bg-background outline-none"
            >
              {children}
            </main>
          </div>
        </OnboardingProvider>
      </GlossaryProviders>
    </InactivityTimeoutGuard>
  );
}
