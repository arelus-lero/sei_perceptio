'use client';

import { useEffect, useRef, type ReactNode } from 'react';

import { OnboardingTour } from '@/components/onboarding/onboarding-tour';
import { useOnboardingStore } from '@/stores/onboarding-store';

interface OnboardingProviderProps {
  onboardingConcluido: boolean;
  children: ReactNode;
}

export function OnboardingProvider({
  onboardingConcluido,
  children,
}: OnboardingProviderProps) {
  const startTour = useOnboardingStore((state) => state.startTour);
  const isActive = useOnboardingStore((state) => state.isActive);
  const autoStartedRef = useRef(false);

  useEffect(() => {
    if (onboardingConcluido || autoStartedRef.current || isActive) {
      return;
    }

    autoStartedRef.current = true;

    const timeoutId = window.setTimeout(() => {
      startTour();
    }, 700);

    return () => window.clearTimeout(timeoutId);
  }, [onboardingConcluido, isActive, startTour]);

  return (
    <>
      {children}
      <OnboardingTour />
    </>
  );
}

export function restartOnboardingTour(): void {
  useOnboardingStore.getState().startTour();
}
