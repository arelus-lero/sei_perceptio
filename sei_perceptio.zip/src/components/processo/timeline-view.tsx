'use client';

import {
  CalendarRange,
  Filter,
  GitBranch,
  GitCompare,
  Landmark,
  Loader2,
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';

import { TimelineChart } from '@/components/processo/timeline-chart';
import { TimelineCompareChart } from '@/components/processo/timeline-compare-chart';
import { TimelineCompareList } from '@/components/processo/timeline-compare-list';
import { TimelineProcessSelector } from '@/components/processo/timeline-process-selector';
import { SeiTerm } from '@/components/glossary/sei-term';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getTimelineProcessColor } from '@/lib/processo/timeline-colors';
import {
  filterCompareProcessos,
  filterTimelineEventos,
} from '@/lib/processo/timeline-filters';
import { processoApiPath } from '@/lib/utils/processo-url';
import type {
  TimelineApiResponse,
  TimelineFilters,
  TimelinePeriodoPreset,
} from '@/types/timeline';

interface TimelineViewProps {
  nup: string;
}

const PERIOD_OPTIONS: { value: TimelinePeriodoPreset; label: string }[] = [
  { value: '30d', label: '30 dias' },
  { value: '90d', label: '90 dias' },
  { value: '180d', label: '6 meses' },
  { value: '365d', label: '1 ano' },
  { value: 'tudo', label: 'Tudo' },
];

const STATUS_LABELS: Record<string, string> = {
  aberto: 'Aberto',
  em_tramitacao: 'Em tramitação',
  concluido: 'Concluído',
  arquivado: 'Arquivado',
};

async function fetchProcessoTimeline(
  nup: string,
): Promise<{ ok: true; data: TimelineApiResponse } | { ok: false; error: string }> {
  try {
    const response = await fetch(processoApiPath(nup, 'timeline'));
    if (!response.ok) {
      const payload = (await response.json().catch(() => null)) as { error?: string } | null;
      throw new Error(payload?.error ?? 'Falha ao carregar linha do tempo');
    }

    const payload = (await response.json()) as TimelineApiResponse;
    return { ok: true, data: payload };
  } catch (loadError) {
    return {
      ok: false,
      error: loadError instanceof Error ? loadError.message : 'Erro ao carregar linha do tempo',
    };
  }
}

export function TimelineView({ nup }: TimelineViewProps) {
  const [data, setData] = useState<TimelineApiResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [compareNups, setCompareNups] = useState<string[]>([]);
  const [compareByNup, setCompareByNup] = useState<Record<string, TimelineApiResponse>>({});
  const [compareErrors, setCompareErrors] = useState<Record<string, string>>({});
  const [compareLoading, setCompareLoading] = useState(false);
  const [filters, setFilters] = useState<TimelineFilters>({
    unidade: null,
    periodo: 'tudo',
    apenasMarcos: false,
  });

  const fetchTimeline = useCallback(async () => fetchProcessoTimeline(nup), [nup]);

  const loadTimeline = useCallback(async () => {
    setLoading(true);
    setError(null);

    const result = await fetchTimeline();
    if (result.ok) {
      setData(result.data);
    } else {
      setError(result.error);
    }

    setLoading(false);
  }, [fetchTimeline]);

  useEffect(() => {
    let active = true;

    queueMicrotask(() => {
      if (!active) {
        return;
      }

      setLoading(true);
      setError(null);
    });

    void fetchTimeline()
      .then((result) => {
        if (!active) {
          return;
        }

        if (result.ok) {
          setData(result.data);
        } else {
          setError(result.error);
        }
      })
      .finally(() => {
        if (active) {
          setLoading(false);
        }
      });

    return () => {
      active = false;
    };
  }, [fetchTimeline]);

  useEffect(() => {
    if (compareNups.length === 0) {
      setCompareByNup({});
      setCompareErrors({});
      setCompareLoading(false);
      return;
    }

    let active = true;
    setCompareLoading(true);

    void Promise.all(compareNups.map((compareNup) => fetchProcessoTimeline(compareNup))).then(
      (results) => {
        if (!active) {
          return;
        }

        const nextData: Record<string, TimelineApiResponse> = {};
        const nextErrors: Record<string, string> = {};

        compareNups.forEach((compareNup, index) => {
          const result = results[index];
          if (!result) {
            return;
          }

          if (result.ok) {
            nextData[compareNup] = result.data;
          } else {
            nextErrors[compareNup] = result.error;
          }
        });

        setCompareByNup(nextData);
        setCompareErrors(nextErrors);
        setCompareLoading(false);
      },
    );

    return () => {
      active = false;
    };
  }, [compareNups]);

  const filteredEventos = useMemo(() => {
    if (!data) {
      return [];
    }
    return filterTimelineEventos(data.eventos, filters);
  }, [data, filters]);

  const allCompareSources = useMemo(() => {
    if (!data) {
      return [];
    }

    const extras = compareNups
      .map((compareNup) => compareByNup[compareNup])
      .filter((item): item is TimelineApiResponse => Boolean(item));

    return [data, ...extras];
  }, [compareByNup, compareNups, data]);

  const compareProcessos = useMemo(
    () => filterCompareProcessos(allCompareSources, filters),
    [allCompareSources, filters],
  );

  const processColors = useMemo(() => {
    const colors: Record<string, string> = {};
    allCompareSources.forEach((processo, index) => {
      colors[processo.nup] = getTimelineProcessColor(index);
    });
    return colors;
  }, [allCompareSources]);

  const allUnidades = useMemo(() => {
    const unidades = new Set<string>();
    for (const processo of allCompareSources) {
      for (const unidade of processo.unidades) {
        unidades.add(unidade);
      }
    }
    return [...unidades].sort((a, b) => a.localeCompare(b, 'pt-BR'));
  }, [allCompareSources]);

  const marcosCount = useMemo(
    () => filteredEventos.filter((evento) => evento.destaque).length,
    [filteredEventos],
  );

  const compareEventosTotal = useMemo(
    () => compareProcessos.reduce((sum, processo) => sum + processo.eventos.length, 0),
    [compareProcessos],
  );

  function handleAddCompareNup(nextNup: string) {
    setCompareNups((current) => [...current, nextNup]);
  }

  function handleRemoveCompareNup(removeNup: string) {
    setCompareNups((current) => current.filter((value) => value !== removeNup));
  }

  if (loading) {
    return (
      <div className="flex items-center gap-2 p-6 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" aria-hidden />
        Carregando linha do tempo...
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="p-6">
        <p className="rounded-lg border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">
          {error ?? 'Linha do tempo indisponível'}
        </p>
        <Button type="button" variant="outline" className="mt-4" onClick={() => void loadTimeline()}>
          Tentar novamente
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-6 p-6">
      <header className="space-y-2">
        <div className="flex flex-wrap items-center gap-2">
          <GitBranch className="size-5 text-primary" aria-hidden />
          <h1 className="text-2xl font-semibold tracking-tight">
            Linha do tempo de <SeiTerm term="andamento">andamentos</SeiTerm>
          </h1>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-sm">{nup}</span>
          <Badge variant="outline">{data.tipo_processo_desc}</Badge>
          <Badge variant="secondary">{STATUS_LABELS[data.status] ?? data.status}</Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          {filteredEventos.length} evento(s) do processo atual
          {marcosCount > 0 ? ` · ${marcosCount} marco(s) destacado(s)` : ''}
          {compareNups.length > 0
            ? ` · comparação com ${allCompareSources.length} processo(s) (${compareEventosTotal} eventos)`
            : ''}
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="size-4" aria-hidden />
            Filtros e zoom
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-3">
          <div className="space-y-2">
            <Label htmlFor="timeline-periodo" className="flex items-center gap-1.5">
              <CalendarRange className="size-3.5" aria-hidden />
              Período
            </Label>
            <select
              id="timeline-periodo"
              className="h-9 w-full rounded-lg border border-input bg-background px-3 text-sm focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-none"
              value={filters.periodo}
              onChange={(event) =>
                setFilters((current) => ({
                  ...current,
                  periodo: event.target.value as TimelinePeriodoPreset,
                }))
              }
            >
              {PERIOD_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="timeline-unidade">Unidade</Label>
            <select
              id="timeline-unidade"
              className="h-9 w-full rounded-lg border border-input bg-background px-3 text-sm focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-none"
              value={filters.unidade ?? ''}
              onChange={(event) =>
                setFilters((current) => ({
                  ...current,
                  unidade: event.target.value || null,
                }))
              }
            >
              <option value="">Todas as unidades</option>
              {allUnidades.map((unidade) => (
                <option key={unidade} value={unidade}>
                  {unidade}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-end gap-2 pb-1">
            <Checkbox
              id="timeline-marcos"
              checked={filters.apenasMarcos}
              onChange={(event) =>
                setFilters((current) => ({
                  ...current,
                  apenasMarcos: event.target.checked,
                }))
              }
            />
            <Label htmlFor="timeline-marcos" className="flex items-center gap-1.5">
              <Landmark className="size-3.5" aria-hidden />
              Apenas marcos
            </Label>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="single">
        <TabsList aria-label="Modo de visualização da linha do tempo">
          <TabsTrigger value="single">Processo atual</TabsTrigger>
          <TabsTrigger value="compare" className="gap-1.5">
            <GitCompare className="size-4" aria-hidden />
            Comparação
          </TabsTrigger>
        </TabsList>

        <TabsContent value="single" className="mt-4 space-y-4">
          <Tabs defaultValue="lista">
            <TabsList aria-label="Formato da linha do tempo">
              <TabsTrigger value="lista">Lista cronológica</TabsTrigger>
              <TabsTrigger value="grafico">Gráfico interativo</TabsTrigger>
            </TabsList>

            <TabsContent value="lista" className="mt-4">
              <TimelineChart eventos={filteredEventos} mode="list" />
            </TabsContent>

            <TabsContent value="grafico" className="mt-4">
              <TimelineChart eventos={filteredEventos} mode="chart" />
            </TabsContent>
          </Tabs>
        </TabsContent>

        <TabsContent value="compare" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Processos na comparação</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <TimelineProcessSelector
                primaryNup={nup}
                selectedNups={compareNups}
                processColors={processColors}
                onAdd={handleAddCompareNup}
                onRemove={handleRemoveCompareNup}
              />

              {compareLoading ? (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Loader2 className="size-3.5 animate-spin" aria-hidden />
                  Carregando processos adicionais...
                </div>
              ) : null}

              {Object.entries(compareErrors).map(([failedNup, message]) => (
                <p
                  key={failedNup}
                  className="rounded-md border border-destructive/30 bg-destructive/5 px-3 py-2 text-xs text-destructive"
                  role="alert"
                >
                  {failedNup}: {message}
                </p>
              ))}
            </CardContent>
          </Card>

          <Tabs defaultValue="grafico">
            <TabsList>
              <TabsTrigger value="grafico">Gráfico comparativo</TabsTrigger>
              <TabsTrigger value="lista">Lista por processo</TabsTrigger>
            </TabsList>

            <TabsContent value="grafico" className="mt-4">
              <TimelineCompareChart processos={compareProcessos} />
            </TabsContent>

            <TabsContent value="lista" className="mt-4">
              <TimelineCompareList processos={compareProcessos} />
            </TabsContent>
          </Tabs>
        </TabsContent>
      </Tabs>
    </div>
  );
}
