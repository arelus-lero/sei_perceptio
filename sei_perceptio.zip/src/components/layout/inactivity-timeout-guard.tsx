'use client';

import type { ReactNode } from 'react';
import { Toaster } from 'sonner';

import { useInactivityTimeout } from '@/hooks/use-inactivity-timeout';

interface InactivityTimeoutGuardProps {
  children: ReactNode;
}

export function InactivityTimeoutGuard({ children }: InactivityTimeoutGuardProps) {
  useInactivityTimeout();

  return (
    <>
      {children}
      <Toaster richColors closeButton position="top-center" />
    </>
  );
}
