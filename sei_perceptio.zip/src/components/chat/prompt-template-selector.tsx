'use client';

import { Check, ChevronsUpDown } from 'lucide-react';
import { useMemo, useState } from 'react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  buildPromptFromTemplate,
  listPromptTemplates,
  type PromptTemplateId,
} from '@/lib/prompts/templates';
import { cn } from '@/lib/utils';

interface PromptTemplateSelectorProps {
  disabled?: boolean;
  onSelect: (payload: { templateId: PromptTemplateId; prompt: string }) => void;
}

export function PromptTemplateSelector({
  disabled = false,
  onSelect,
}: PromptTemplateSelectorProps) {
  const templates = useMemo(() => listPromptTemplates(), []);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState<PromptTemplateId | null>(null);

  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) {
      return templates;
    }

    return templates.filter(
      (template) =>
        template.label.toLowerCase().includes(normalized)
        || template.description.toLowerCase().includes(normalized),
    );
  }, [query, templates]);

  const selected = selectedId
    ? templates.find((template) => template.id === selectedId)
    : null;

  function handleSelect(templateId: PromptTemplateId) {
    const prompt = buildPromptFromTemplate(templateId);
    setSelectedId(templateId);
    setOpen(false);
    setQuery('');
    onSelect({ templateId, prompt });
  }

  return (
    <div className="relative">
      <Button
        type="button"
        variant="outline"
        size="sm"
        disabled={disabled}
        className="w-full justify-between font-normal"
        aria-expanded={open}
        aria-haspopup="listbox"
        onClick={() => setOpen((current) => !current)}
      >
        <span className="truncate">
          {selected ? selected.label : 'Template de análise (RF-018)'}
        </span>
        <ChevronsUpDown className="size-4 shrink-0 opacity-60" aria-hidden />
      </Button>

      {open ? (
        <div
          className="absolute bottom-full z-50 mb-1 w-full rounded-lg border border-border bg-popover p-2 shadow-md"
          role="listbox"
        >
          <Input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Buscar template…"
            className="mb-2 h-8"
            autoFocus
          />
          <ul className="max-h-56 space-y-0.5 overflow-y-auto">
            {filtered.length === 0 ? (
              <li className="px-2 py-3 text-sm text-muted-foreground">
                Nenhum template encontrado.
              </li>
            ) : (
              filtered.map((template) => {
                const isSelected = template.id === selectedId;
                return (
                  <li key={template.id}>
                    <button
                      type="button"
                      role="option"
                      aria-selected={isSelected}
                      className={cn(
                        'flex w-full items-start gap-2 rounded-md px-2 py-2 text-left text-sm hover:bg-muted',
                        isSelected && 'bg-muted',
                      )}
                      onClick={() => handleSelect(template.id)}
                    >
                      <Check
                        className={cn(
                          'mt-0.5 size-4 shrink-0',
                          isSelected ? 'opacity-100' : 'opacity-0',
                        )}
                        aria-hidden
                      />
                      <span className="min-w-0">
                        <span className="block font-medium">{template.label}</span>
                        <span className="block text-xs text-muted-foreground">
                          {template.description}
                        </span>
                      </span>
                    </button>
                  </li>
                );
              })
            )}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
