'use client';

import { useState } from 'react';
import { ExternalLink } from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { SeiTerm } from '@/components/glossary/sei-term';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import type { ChatCitation } from '@/types/chat';

interface CitationCardProps {
  citation: ChatCitation;
  className?: string;
  onSelectSource?: (sourceId: string) => void;
}

export function CitationCard({
  citation,
  className,
  onSelectSource,
}: CitationCardProps) {
  const [expanded, setExpanded] = useState(false);

  return (
    <Card
      className={cn(
        'cursor-pointer transition-colors hover:bg-muted/40',
        className,
      )}
      onClick={() => {
        setExpanded((value) => !value);
        onSelectSource?.(citation.source_id);
      }}
    >
      <CardContent className="space-y-2 p-3">
        <div className="flex items-start justify-between gap-2">
          <div className="space-y-1">
            <p className="text-xs font-medium">
              <span className="text-muted-foreground">
                <SeiTerm term="numero_sei">Nº SEI</SeiTerm>:{' '}
              </span>
              {citation.numero_sei}
            </p>
            <p className="text-xs text-muted-foreground">
              {citation.tipo} · {citation.unidade}
            </p>
          </div>
          <div className="flex items-center gap-1">
            <Badge variant="secondary">
              {citation.score.toFixed(2)}
            </Badge>
            <ExternalLink className="size-3.5 text-muted-foreground" />
          </div>
        </div>
        {expanded ? (
          <p className="text-xs leading-relaxed text-muted-foreground">
            {citation.trecho}
          </p>
        ) : (
          <p className="line-clamp-2 text-xs leading-relaxed text-muted-foreground">
            {citation.trecho}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
