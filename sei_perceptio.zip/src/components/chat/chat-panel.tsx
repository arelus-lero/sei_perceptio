'use client';

import { useCallback, useMemo, useState } from 'react';
import Link from 'next/link';
import { Loader2, SendHorizontal } from 'lucide-react';

import { MessageBubble } from '@/components/chat/message-bubble';
import {
  buildChatRequestFiltros,
  ChatStructuredFilters,
  EMPTY_CHAT_STRUCTURED_FILTERS,
  type ChatStructuredFilterState,
} from '@/components/chat/chat-structured-filters';
import { PromptTemplateSelector } from '@/components/chat/prompt-template-selector';
import { SourceSelector } from '@/components/chat/source-selector';
import { TagFilter } from '@/components/tags/tag-filter';
import { ConversationHistory } from '@/components/notebook/conversation-history';
import { SourceUpload } from '@/components/notebook/source-upload';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { useChat } from '@/hooks/use-chat';
import { useTags } from '@/hooks/use-tags';
import type { PromptTemplateId } from '@/lib/prompts/templates';
import { cn } from '@/lib/utils';
import type { NotebookFonte } from '@/types/chat';
import type { TagItem } from '@/types/tag';

interface ChatPanelProps {
  notebookId: string;
  notebookName: string;
  fontes: NotebookFonte[];
  canUpload: boolean;
  canAssignTags?: boolean;
  className?: string;
}

export function ChatPanel({
  notebookId,
  notebookName,
  fontes: initialFontes,
  canUpload,
  canAssignTags = false,
  className,
}: ChatPanelProps) {
  const [fontes, setFontes] = useState<NotebookFonte[]>(initialFontes);

  const defaultActiveIds = useMemo(
    () => fontes.filter((fonte) => fonte.ativa).map((fonte) => fonte.id),
    [fontes],
  );

  const [activeSourceIds, setActiveSourceIds] = useState<string[]>(defaultActiveIds);
  const [input, setInput] = useState('');
  const [selectedTemplateId, setSelectedTemplateId] = useState<PromptTemplateId | null>(
    null,
  );
  const [filterTagIds, setFilterTagIds] = useState<string[]>([]);
  const [chatFilterTagIds, setChatFilterTagIds] = useState<string[]>([]);
  const [structuredFilters, setStructuredFilters] = useState<ChatStructuredFilterState>(
    EMPTY_CHAT_STRUCTURED_FILTERS,
  );
  const [highlightedSourceId, setHighlightedSourceId] = useState<string | null>(null);

  const {
    tags: orgTags,
    loading: tagsLoading,
    error: tagsError,
    createTag,
    linkTag,
    unlinkTag,
  } = useTags();

  const {
    messages,
    conversaId,
    isLoading,
    error,
    sendMessage,
    loadConversation,
    startNewConversation,
  } = useChat({ notebookId });

  const activeRagTagIds = useMemo(() => {
    const merged = new Set([...filterTagIds, ...chatFilterTagIds]);
    return [...merged];
  }, [chatFilterTagIds, filterTagIds]);

  function handleToggleSource(sourceId: string, active: boolean) {
    setActiveSourceIds((current) => {
      if (active) {
        return current.includes(sourceId) ? current : [...current, sourceId];
      }
      return current.filter((id) => id !== sourceId);
    });
  }

  function handleToggleFilterTag(tagId: string) {
    setFilterTagIds((current) =>
      current.includes(tagId)
        ? current.filter((id) => id !== tagId)
        : [...current, tagId],
    );
  }

  function handleToggleChatFilterTag(tagId: string) {
    setChatFilterTagIds((current) =>
      current.includes(tagId)
        ? current.filter((id) => id !== tagId)
        : [...current, tagId],
    );
  }

  const updateFonteTags = useCallback((fonteId: string, updater: (tags: TagItem[]) => TagItem[]) => {
    setFontes((current) =>
      current.map((fonte) =>
        fonte.id === fonteId
          ? { ...fonte, tags: updater(fonte.tags ?? []) }
          : fonte,
      ),
    );
  }, []);

  const handleLinkTag = useCallback(
    async (fonteId: string, tagId: string) => {
      await linkTag(fonteId, tagId);
      const linked = orgTags.find((tag) => tag.id === tagId);
      if (linked) {
        updateFonteTags(fonteId, (tags) =>
          tags.some((tag) => tag.id === tagId) ? tags : [...tags, linked],
        );
      }
    },
    [linkTag, orgTags, updateFonteTags],
  );

  const handleUnlinkTag = useCallback(
    async (fonteId: string, tagId: string) => {
      await unlinkTag(fonteId, tagId);
      updateFonteTags(fonteId, (tags) => tags.filter((tag) => tag.id !== tagId));
    },
    [unlinkTag, updateFonteTags],
  );

  const handleCreateTag = useCallback(
    async (nome: string) => createTag({ nome }),
    [createTag],
  );

  function handleSelectSource(sourceId: string) {
    setHighlightedSourceId(sourceId);
    document.getElementById(`fonte-${sourceId}`)?.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
    });
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const mensagem = input.trim();
    if (!mensagem) {
      return;
    }

    setInput('');
    await sendMessage({
      mensagem,
      fontesAtivas: activeSourceIds,
      templateId: selectedTemplateId ?? undefined,
      filtros: buildChatRequestFiltros(structuredFilters, activeRagTagIds),
    });
  }

  function handleTemplateSelect(payload: {
    templateId: PromptTemplateId;
    prompt: string;
  }) {
    setSelectedTemplateId(payload.templateId);
    setInput(payload.prompt);
  }

  return (
    <div className={cn('grid h-[calc(100vh-4rem)] gap-4 lg:grid-cols-[320px_1fr]', className)}>
      <Card className="flex h-full flex-col overflow-hidden">
        <CardHeader className="space-y-2">
          <Button asChild variant="ghost" size="sm" className="w-fit px-0">
            <Link href="/notebooks">← Notebooks</Link>
          </Button>
          <CardTitle>Fontes</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-1 flex-col overflow-hidden p-0">
          <SourceSelector
            fontes={fontes}
            activeSourceIds={activeSourceIds}
            onToggle={handleToggleSource}
            highlightedSourceId={highlightedSourceId}
            orgTags={orgTags}
            tagsLoading={tagsLoading}
            tagsError={tagsError}
            filterTagIds={filterTagIds}
            onToggleFilterTag={handleToggleFilterTag}
            canAssignTags={canAssignTags}
            onLinkTag={handleLinkTag}
            onUnlinkTag={handleUnlinkTag}
            onCreateTag={canAssignTags ? handleCreateTag : undefined}
          />
          <SourceUpload notebookId={notebookId} canUpload={canUpload} />
          <ConversationHistory
            notebookId={notebookId}
            activeConversaId={conversaId}
            onSelectConversation={loadConversation}
            onStartNewConversation={startNewConversation}
          />
        </CardContent>
      </Card>

      <Card className="flex h-full flex-col overflow-hidden">
        <CardHeader>
          <CardTitle>{notebookName}</CardTitle>
        </CardHeader>

        <CardContent className="flex flex-1 flex-col gap-4 overflow-hidden p-0">
          <ScrollArea className="flex-1 px-4">
            <div
              className="space-y-4 py-4"
              role="log"
              aria-live="polite"
              aria-relevant="additions"
              aria-label="Histórico de mensagens"
            >
              {messages.length === 0 ? (
                <p className="text-sm text-muted-foreground">
                  Faça uma pergunta sobre as fontes selecionadas. As respostas incluem
                  citações rastreáveis e selo de IA.
                </p>
              ) : null}

              {messages.map((message) => (
                <MessageBubble
                  key={message.id}
                  message={message}
                  onSelectSource={handleSelectSource}
                />
              ))}
            </div>
          </ScrollArea>

          {error ? (
            <p className="px-4 text-sm text-destructive" role="alert">
              {error}
            </p>
          ) : null}

          <form onSubmit={handleSubmit} className="border-t p-4">
            <div className="mb-2 space-y-2">
              <PromptTemplateSelector
                disabled={isLoading}
                onSelect={handleTemplateSelect}
              />
              <ChatStructuredFilters
                value={structuredFilters}
                onChange={setStructuredFilters}
                disabled={isLoading}
              />
              <TagFilter
                tags={orgTags}
                activeTagIds={chatFilterTagIds}
                onToggle={handleToggleChatFilterTag}
                loading={tagsLoading}
                error={tagsError}
                label="Tags ativas na consulta RAG"
              />
            </div>
            <div className="flex gap-2">
              <label htmlFor="chat-message-input" className="sr-only">
                Mensagem para consulta RAG
              </label>
              <Textarea
                id="chat-message-input"
                data-tour="chat-input"
                value={input}
                onChange={(event) => setInput(event.target.value)}
                placeholder="Pergunte sobre os documentos do notebook…"
                disabled={isLoading}
                rows={3}
              />
              <Button
                type="submit"
                disabled={isLoading || input.trim().length === 0}
                className="self-end"
                aria-label="Enviar mensagem"
              >
                {isLoading ? <Loader2 className="animate-spin" aria-hidden /> : <SendHorizontal aria-hidden />}
                Enviar
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
